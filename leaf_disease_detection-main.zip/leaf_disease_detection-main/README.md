# leaf_disease_detection
LINK TO DATASET-https://www.kaggle.com/emmarex/plantdisease
